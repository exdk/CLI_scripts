<?php
// Подключаем все необходимые файлы
require_once 'src/HtmlElement.php';
require_once 'src/traits/EditableTrait.php';
require_once 'src/traits/NumberFormatTrait.php';
require_once 'src/elements/InputText.php';
require_once 'src/elements/InputNumber.php';
require_once 'src/elements/SpanText.php';
require_once 'src/elements/SpanNumber.php';
require_once 'src/elements/Link.php';

echo "=== HTML Elements System Demo ===\n\n";

// 1. Текстовый input
echo "1. Текстовое поле ввода:\n";
$textInput = (new InputText('username', 'form-control'))
    ->setName('username')
    ->setValue('John Doe')
    ->setPlaceholder('Enter your name')
    ->setRequired(true);
echo "Код: " . $textInput->render() . "\n\n";

// 2. Числовой input с форматированием
echo "2. Числовое поле с форматированием:\n";
$numberInput = (new InputNumber('price', 'price-input'))
    ->setName('price')
    ->setValue(1234.567)
    ->setNumberFormat(2, '.', ',')
    ->setPlaceholder('0.00')
    ->setRequired(true);
echo "Код: " . $numberInput->render() . "\n\n";

// 3. Статический текстовый элемент
echo "3. Статический текстовый элемент:\n";
$spanText = (new SpanText('label1', 'info-text'))
    ->setValue('Total:');
echo "Код: " . $spanText->render() . "\n\n";

// 4. Статический числовой элемент с форматированием
echo "4. Статический числовой элемент с форматированием:\n";
$spanNumber = (new SpanNumber('total', 'total-value'))
    ->setValue(9876.54321)
    ->setNumberFormat(2, ',', ' ');
echo "Код: " . $spanNumber->render() . "\n\n";

// 5. Ссылка
echo "5. Ссылка:\n";
$link = (new Link('home-link', 'nav-link'))
    ->setHref('/home')
    ->setText('Go Home')
    ->setAttribute('target', '_blank');
echo "Код: " . $link->render() . "\n\n";

// 6. Пример формы
echo "6. Пример формы с элементами:\n";
echo "<form>\n";
echo "  Имя: " . $textInput->render() . "<br>\n";
echo "  Цена: " . $numberInput->render() . "<br>\n";
echo "  " . $spanText->render() . " " . $spanNumber->render() . "<br>\n";
echo "  " . $link->render() . "<br>\n";
echo "  <button type='submit'>Отправить</button>\n";
echo "</form>\n\n";

// 7. Тест наследования
echo "7. Тест наследования и трейтов:\n";

$testNumber = (new InputNumber())
    ->setValue(1000.5)
    ->setNumberFormat(0, '.', ' ');
echo "Число 1000.5 с форматированием: " . $testNumber->render() . "\n";

// 8. Вывод дерева классов
echo "\n8. Дерево классов системы:\n";
echo "HtmlElement (базовый класс)\n";
echo "├── InputText (редактируемый текст)\n";
echo "│   └── InputNumber (редактируемое число)\n";
echo "├── SpanText (статический текст)\n";
echo "│   └── SpanNumber (статическое число)\n";
echo "└── Link (ссылка)\n";
echo "\nТрейты:\n";
echo "├── NumberFormatTrait (форматирование чисел)\n";
echo "└── EditableTrait (редактируемые элементы)\n";