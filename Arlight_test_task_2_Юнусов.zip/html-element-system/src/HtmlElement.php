<?php

abstract class HtmlElement
{
    protected string $id = '';
    protected string $class = '';
    protected string $name = '';
    protected $value = '';
    protected array $attributes = [];

    public function __construct(string $id = '', string $class = '')
    {
        $this->id = $id;
        $this->class = $class;
    }

    public function setId(string $id): self
    {
        $this->id = $id;
        return $this;
    }

    public function setClass(string $class): self
    {
        $this->class = $class;
        return $this;
    }

    public function setName(string $name): self
    {
        $this->name = $name;
        return $this;
    }

    public function setValue($value): self
    {
        $this->value = $value;
        return $this;
    }

    public function setAttribute(string $name, $value): self
    {
        $this->attributes[$name] = $value;
        return $this;
    }

    protected function renderAttributes(): string
    {
        $attrs = [];
        
        if ($this->id) {
            $attrs[] = 'id="' . htmlspecialchars($this->id) . '"';
        }
        
        if ($this->class) {
            $attrs[] = 'class="' . htmlspecialchars($this->class) . '"';
        }
        
        if ($this->name) {
            $attrs[] = 'name="' . htmlspecialchars($this->name) . '"';
        }

        foreach ($this->attributes as $key => $value) {
            if ($value !== null && $value !== '') {
                $attrs[] = $key . '="' . htmlspecialchars($value) . '"';
            }
        }
        
        return $attrs ? ' ' . implode(' ', $attrs) : '';
    }

    abstract public function render(): string;
}