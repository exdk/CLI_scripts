<?php

require_once DIR . '/InputText.php';
require_once DIR . '/../traits/NumberFormatTrait.php';

class InputNumber extends InputText
{
    use NumberFormatTrait;

    public function setValue($value): self
    {
        if ($this->decimals !== null && is_numeric($value)) {
            $this->value = $this->formatNumber($value);
        } else {
            $this->value = $value;
        }
        return $this;
    }

    public function render(): string
    {
        $attributes = $this->renderAttributes();
        $editableAttrs = $this->renderEditableAttributes();
        $value = htmlspecialchars((string)$this->value);
        
        return '<input type="number" value="' . $value . '"' . $attributes . $editableAttrs . '>';
    }
}