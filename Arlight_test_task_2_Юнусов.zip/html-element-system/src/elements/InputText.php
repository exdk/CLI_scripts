<?php

require_once DIR . '/../HtmlElement.php';
require_once DIR . '/../traits/EditableTrait.php';

class InputText extends HtmlElement
{
    use EditableTrait;

    public function render(): string
    {
        $attributes = $this->renderAttributes();
        $editableAttrs = $this->renderEditableAttributes();
        $value = htmlspecialchars((string)$this->value);
        
        return '<input type="text" value="' . $value . '"' . $attributes . $editableAttrs . '>';
    }
}