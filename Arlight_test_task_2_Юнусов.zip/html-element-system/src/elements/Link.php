<?php

require_once DIR . '/../HtmlElement.php';

class Link extends HtmlElement
{
    protected string $href = '';
    protected string $text = '';

    public function setHref(string $href): self
    {
        $this->href = $href;
        return $this;
    }

    public function setText(string $text): self
    {
        $this->text = $text;
        return $this;
    }

    public function render(): string
    {
        $attributes = $this->renderAttributes();
        $href = $this->href ? ' href="' . htmlspecialchars($this->href) . '"' : '';
        $content = htmlspecialchars($this->text ?: (string)$this->value);
        
        return '<a' . $href . $attributes . '>' . $content . '</a>';
    }
}