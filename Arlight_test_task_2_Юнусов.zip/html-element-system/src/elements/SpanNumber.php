<?php

require_once DIR . '/SpanText.php';
require_once DIR . '/../traits/NumberFormatTrait.php';

class SpanNumber extends SpanText
{
    use NumberFormatTrait;

    public function setValue($value): self
    {
        if (is_numeric($value)) {
            $this->value = $this->formatNumber($value);
        } else {
            $this->value = $value;
        }
        return $this;
    }
}