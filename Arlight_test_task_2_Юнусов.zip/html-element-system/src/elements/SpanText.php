<?php

require_once DIR . '/../HtmlElement.php';

class SpanText extends HtmlElement
{
    public function render(): string
    {
        $attributes = $this->renderAttributes();
        $content = htmlspecialchars((string)$this->value);
        
        return '<span' . $attributes . '>' . $content . '</span>';
    }
}