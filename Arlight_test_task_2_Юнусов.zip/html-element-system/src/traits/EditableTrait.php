<?php

trait EditableTrait
{
    protected string $placeholder = '';
    protected bool $required = false;

    public function setPlaceholder(string $placeholder): self
    {
        $this->placeholder = $placeholder;
        return $this;
    }

    public function setRequired(bool $required): self
    {
        $this->required = $required;
        return $this;
    }

    protected function renderEditableAttributes(): string
    {
        $attrs = [];
        
        if ($this->placeholder) {
            $attrs[] = 'placeholder="' . htmlspecialchars($this->placeholder) . '"';
        }
        
        if ($this->required) {
            $attrs[] = 'required';
        }
        
        return $attrs ? ' ' . implode(' ', $attrs) : '';
    }
}