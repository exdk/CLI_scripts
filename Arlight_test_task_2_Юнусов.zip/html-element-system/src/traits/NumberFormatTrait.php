<?php

trait NumberFormatTrait
{
    protected ?int $decimals = null;
    protected string $decimalSeparator = '.';
    protected string $thousandsSeparator = '';

    public function setNumberFormat(
        ?int $decimals = null,
        string $decimalSeparator = '.',
        string $thousandsSeparator = ''
    ): self {
        $this->decimals = $decimals;
        $this->decimalSeparator = $decimalSeparator;
        $this->thousandsSeparator = $thousandsSeparator;
        return $this;
    }

    public function formatNumber($value): string
    {
        if (!is_numeric($value)) {
            return (string)$value;
        }

        if ($this->decimals !== null) {
            return number_format(
                (float)$value,
                $this->decimals,
                $this->decimalSeparator,
                $this->thousandsSeparator
            );
        }

        return (string)$value;
    }
}